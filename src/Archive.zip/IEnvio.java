public interface IEnvio {

  void cargarMercancia();

  void rastrearPaquete();

  boolean permitidoEnAvion();
}
